import sys
sys.stdin=open("./Me/section06/input.txt", "r")